# Distributed URL Shortener

A system-design focused software engineering project similar to Bitly/TinyURL. It supports URL shortening, custom short codes, redirection, and click analytics.

## Features
- Create short URLs
- Custom aliases
- Redirect short URLs
- Track click count
- REST APIs with FastAPI
- React frontend
- Docker Compose setup

## Tech Stack
**Frontend:** React, Vite  
**Backend:** Python, FastAPI  
**Database:** SQLite locally; PostgreSQL-ready  
**Deployment:** Docker, Docker Compose

## Architecture Diagram
![Architecture](./screenshots/architecture.svg)

## Workflow Diagram
![Workflow](./screenshots/workflow.svg)

## Run With Docker
```bash
docker-compose up --build
```
Frontend: `http://localhost:5173`  
Backend Swagger: `http://localhost:8000/docs`

## API Endpoints
```http
POST /api/shorten
GET /{short_code}
GET /api/stats/{short_code}
```

## Portfolio Description
Built a distributed URL shortener system with FastAPI and React supporting short link generation, custom aliases, redirects, and click analytics. Designed the architecture to demonstrate hashing, caching, rate limiting, database indexing, and horizontal scalability.

## Resume Bullets
- Built a distributed URL shortener using FastAPI, React, and SQL-based storage with URL redirection, custom aliases, and click analytics.
- Designed a system architecture with scalability concepts including caching, indexing, rate limiting, and load balancing for high-throughput URL redirection.
- Implemented REST APIs for URL creation, redirects, and analytics, and containerized the full application using Docker Compose.
