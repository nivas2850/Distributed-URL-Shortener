import shortuuid
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from app.database import Base, engine, get_db
from app.models import URLMapping
from app.schemas import URLCreate, URLResponse, URLStats
Base.metadata.create_all(bind=engine)
app=FastAPI(title='Distributed URL Shortener', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])
APP_BASE_URL='http://localhost:8000'
@app.get('/health')
def health(): return {'status':'healthy'}
@app.post('/api/shorten', response_model=URLResponse)
def shorten(payload: URLCreate, db: Session=Depends(get_db)):
    code=payload.custom_code or shortuuid.ShortUUID().random(length=7)
    if db.query(URLMapping).filter(URLMapping.short_code==code).first():
        raise HTTPException(status_code=409, detail='Short code already exists')
    item=URLMapping(short_code=code, original_url=str(payload.original_url))
    db.add(item); db.commit(); db.refresh(item)
    return {'short_code':code,'short_url':f'{APP_BASE_URL}/{code}','original_url':item.original_url}
@app.get('/{short_code}')
def redirect(short_code: str, db: Session=Depends(get_db)):
    item=db.query(URLMapping).filter(URLMapping.short_code==short_code).first()
    if not item: raise HTTPException(status_code=404, detail='URL not found')
    item.clicks += 1; db.commit()
    return RedirectResponse(item.original_url)
@app.get('/api/stats/{short_code}', response_model=URLStats)
def stats(short_code: str, db: Session=Depends(get_db)):
    item=db.query(URLMapping).filter(URLMapping.short_code==short_code).first()
    if not item: raise HTTPException(status_code=404, detail='URL not found')
    return item
