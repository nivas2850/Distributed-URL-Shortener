from pydantic import BaseModel, HttpUrl
from datetime import datetime
class URLCreate(BaseModel):
    original_url: HttpUrl
    custom_code: str | None = None
class URLResponse(BaseModel):
    short_code: str
    short_url: str
    original_url: str
class URLStats(BaseModel):
    short_code: str
    original_url: str
    clicks: int
    created_at: datetime
