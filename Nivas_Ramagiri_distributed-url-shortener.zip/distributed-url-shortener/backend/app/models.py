from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime
from app.database import Base
class URLMapping(Base):
    __tablename__='url_mappings'
    id=Column(Integer, primary_key=True, index=True)
    short_code=Column(String(32), unique=True, index=True, nullable=False)
    original_url=Column(String(2048), nullable=False)
    clicks=Column(Integer, default=0)
    created_at=Column(DateTime, default=datetime.utcnow)
