import React,{useState}from'react';import{createRoot}from'react-dom/client';import axios from'axios';import'./style.css';
const API='http://localhost:8000';
function App(){const[url,setUrl]=useState('');const[custom,setCustom]=useState('');const[result,setResult]=useState(null);const[stats,setStats]=useState(null);
const shorten=async()=>{const r=await axios.post(`${API}/api/shorten`,{original_url:url,custom_code:custom||null});setResult(r.data)};
const getStats=async()=>{const r=await axios.get(`${API}/api/stats/${result.short_code}`);setStats(r.data)};
return <div className='page'><div className='card'><h1>Distributed URL Shortener</h1><p>System design project with redirects and analytics.</p><input placeholder='Long URL' value={url} onChange={e=>setUrl(e.target.value)}/><input placeholder='Custom code optional' value={custom} onChange={e=>setCustom(e.target.value)}/><button onClick={shorten}>Shorten URL</button>{result&&<div className='result'><h3>Short URL</h3><a href={result.short_url} target='_blank'>{result.short_url}</a><br/><button onClick={getStats}>View Analytics</button></div>}{stats&&<div className='stats'><b>Clicks:</b> {stats.clicks}<br/><b>Original:</b> {stats.original_url}</div>}</div></div>}
createRoot(document.getElementById('root')).render(<App/>);
